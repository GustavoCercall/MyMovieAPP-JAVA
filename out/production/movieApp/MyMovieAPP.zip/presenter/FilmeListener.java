package presenter;

public interface FilmeListener { // passar os dados já formatados, com imagem junto.
    void infoFilme(Filme filme);


}//transição de dados pra tela
