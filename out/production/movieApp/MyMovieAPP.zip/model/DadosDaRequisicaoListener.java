package model;

import presenter.Filme;

import java.awt.*;

public interface DadosDaRequisicaoListener {
    void converteDados(String convertedora, Image poster); // listener com a assinatura da função
                                                            // para tratar o JSON.


}//conversão de dados
