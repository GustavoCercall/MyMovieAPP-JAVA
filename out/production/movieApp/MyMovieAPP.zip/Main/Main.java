package Main;

import Screens.BuscaFilmes;

public class Main {
    public static BuscaFilmes BuscaFilmes;

    public static void main(String[] args) {
        BuscaFilmes = new BuscaFilmes();
        BuscaFilmes.setVisible(true);

    }


}
